import aiohttp
import asyncio
from datetime import datetime

async def main() -> None:
    pass

if __name__ == "__main__":
    asyncio.run(main())