from abc import ABC, abstractmethod #mechanizm pozwalajacy tworzyc klasy abstrakcyjne Abstract Base Classes
from typing import Iterable

from core.domain.movie import Movie, MovieIn
from core.domain.review import Review, ReviewIn


class IMovieService(ABC):
    """"""

    @abstractmethod
    async def get_all(self) -> Iterable[Movie]:
        """metoda wydobywająca wszystkie filmy z repozytorium"""

    @abstractmethod
    async def get_movie(self, id: int):
        pass

    @abstractmethod
    async def get_movie_by_title(self, title: str):
        pass

    @abstractmethod
    async def get_movie_by_genre(self, genre: str):
        pass

    @abstractmethod
    async def get_movie_by_rating(self, rating: int):
        pass

    @abstractmethod
    async def get_movie_by_age_restriction(self, age: int):
        pass



    """tylko ADMIN"""

    @abstractmethod
    async def create_movie(self, data: MovieIn):
        pass

    @abstractmethod
    async def remove_movie(self, id: int):
        pass

    @abstractmethod
    async def update_movie(self, id: int):
        pass



"""WIP"""
"""
    @abstractmethod
    async def get_all_movie_reviews(self) -> Iterable[Review]:
        pass
"""