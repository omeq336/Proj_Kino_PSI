from core.domain.movie import Movie, MovieIn
from core.respositories.imovie import IMovieRepository
from infrastructure.services.imovie import IMovieService

from typing import Iterable

class MovieService(IMovieRepository):

    _repository: IMovieRepository

    def __init__(self, repository: IMovieRepository) -> None:
        """inicjalizacja serwisu movie service"""
        self._repository = repository

    async def get_all(self) -> Iterable[Movie]:
        """metoda wydobywająca wszystkie filmy z repozytorium"""
        return await self._repository.get_all_movies()

    async def get_movie_by_id(self, id: int):
        return await self._repository.get_movie_by_id(id)

    async def get_movie_by_title(self, title: str):
        return await self._repository.get_movie_by_title(title)

    async def get_movie_by_genre(self, genre: str):
        return await self._repository.get_movie_by_genre(genre)

    async def get_movie_by_rating(self, rating: int):
        return await self._repository.get_movie_by_rating(rating)

    async def get_movie_by_age_restriction(self, age: int):
        return await self._repository.get_movie_by_age_restriction(age)



    """tylko ADMIN"""

    async def create_movie(self, data: MovieIn):
        return await self._repository.add(data)

    async def remove_movie(self, id: int):
        return await self._repository.create(id)

    async def update_movie(self, id: int, data: MovieIn):
        return await self._repository.create(id, title, genre, duration, language, age_restriction)
