from core.domain.movie import Movie, MovieIn
from core.respositories.imovie import IMovieRepository
from infrastructure.repositories.db import movies

from typing import Iterable
from typing import Optional

class MovieMockRepository(IMovieRepository):


    async def get_all_movies(self) -> Iterable[Movie]:
        return movies

    async def get_movie_by_id(self, id: int):
        for movie in movies:
            if movie.id == id:
                return movie

    async def get_movie_by_title(self, title: str):
        for movie in movies:
            if movie.title == title:
                return movie

    async def get_movie_by_genre(self, genre: str):
        for movie in movies:
            if movie.genre == genre:
                return movie

    async def get_movie_by_rating(self, rating: int):
        for movie in movies:
            if movie.rating >= rating:
                return movie

    async def get_movie_by_age_restriction(self, age: int):
        for movie in movies:
            if movie.age_restriction >= age:
                return movie


    """admin"""
    async def create_movie(self, data: MovieIn) -> None:
        movies.append(data)

    async def remove_movie(self, id: int):
        for movie in movies:
            if movie.id == id:
                movies.remove(movie)

    async def update_movie(self, id: int, data: MovieIn):

        for movie in movies:
            if movie.id == id:
                movie.title = data.title
                movie.genre = data.genre
                movie.duration = data.duration
                movie.language = data.language
                movie.age_restriction = data.age_restriction
