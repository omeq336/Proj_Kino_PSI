from dependency_injector.wiring import inject, Provide
from fastapi import APIRouter, Depends

from container import Container
from core.domain.movie import Movie, MovieIn
from infrastructure.services.imovie import IMovieService



router = APIRouter()

@router.get("/all", response_model=list(Movie), status_code=200)
@inject
async def get_all_movies(service: IMovieService = Depends(Provide[Container.movie_service])) -> list:
    movies = await service.get_all()
    return [{**movies.model_dump(), "id": 0} for i, movie in enumerate(movies)]

@router.get("/movie/{id}", response_model=list(Movie, status_code=200))
@inject
async def get_movie_by_id(id: int, service: IMovieService = Depends(Provide[Container.movie_service])):
    movies = await service.get_all()
    return movies[0]

@router.get("/movie/{title}", response_model=list(Movie, status_code=200))
@inject
async def get_movie_by_title(title: str, service: IMovieService = Depends(Provide[Container.movie_service])) -> list:
    movies = await service.get_movie_by_title()
    return [{**movies.model_dump(), "id": 0} for i, movie in enumerate(movies)]

@router.get("/movie/{genre}", response_model=list(Movie, status_code=200))
@inject
async def get_movie_by_genre(genre: str, service: IMovieService = Depends(Provide[Container.movie_service])) -> list:
    movies = await service.get_movie_by_genre()
    return [{**movies.model_dump(), "id": 0} for i, movie in enumerate(movies)]


@router.get("/movie/{rating}", response_model=list(Movie,status_code=200))
@inject
async def get_movie_by_rating(rating: int, service: IMovieService = Depends(Provide[Container.movie_service])) -> list:
    movies = await service.get_movie_by_rating()
    return [{**movies.model_dump(), "id": 0} for i, movie in enumerate(movies)]

@router.get("/movie/{age_restriction}", response_model=list(Movie, status_code=200))
@inject
async def get_movie_by_age_restriction(age: int, service: IMovieServce = Depends(Provide[Container.movie_service])) -> list:
    movies = await service.get_movie_by_age_restriction()
    return [{**movies.model_dump(), "id": 0} for i, movie in enumerate(movies)]

"""Sekcja admina"""

@router.post("/create", response_model=Movie, status_code=201)
@inject
async def create_movie(data: MovieIn, service: IMovieService = Depends(Provide[Container.movie_service])) -> dict:
    await service.create_movie(data)

    return {**data.model_dump(), "id": 0}

async def remove_movie(self, id: int):
    return await self._repository.create(id)

@router.post("/update", response_model=Movie, status_code=201)
@incject
async def update_movie(movie_id: int, updated_movie: MovieIn, service: IMovieService = Depends(Provide[Container.movie_service])) -> dict:
    if await service.get_movie_by_id(movie_id):
        await service.update_movie(
        pass #WIP
        )
