from dataclasses import dataclass
from pydantic import BaseModel, ConfigDict

@dataclass
class ReviewIn(BaseModel):
    review_id: int # id po którym łączymy z movie
    rating: int # od 1 - 10
    comment: str


class Review(ReviewIn):
    #Reprezentacja w bazie danych
    id: int

    model_config = ConfigDict(from_attributes=True, extra="ignore")