from datetime import datetime
from pydantic import BaseModel, ConfigDict
from dataclasses import dataclass
from typing import Optional, List

from movie import MovieIn #import klasy movie w celu dodania filmu

@dataclass
class RepertoireIn(BaseModel):
    movie_list: List[Optional[MovieIn]] = None
    movie_time: Optional[datetime.time] = None #godzina rozpoczęcia filmu
    movie_date: Optional[datetime] = None
    hall: Optional[str] = None
    # movie_language: str


class Repertoire(RepertoireIn):
    #Reprezentacja w bazie danych
    id: int

    model_config = ConfigDict(from_attributes=True, extra="ignore")