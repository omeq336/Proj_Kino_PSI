from dataclasses import dataclass
from pydantic import BaseModel, ConfigDict
from typing import Optional

@dataclass
class MovieIn(BaseModel):
    repertoire_id: int
    title: str #nazwa
    genre: str #gatunek
    duration: int #czas trwania
    age_restriction: int #ograniczenie wiekowe
    rating: Optional[int] = None
    #review_list: list


class Movie(MovieIn):
    #Reprezentacja w bazie danych
    id: int

    model_config = ConfigDict(from_attributes=True, extra="ignore")

