from dependency_injector.containers import DeclarativeContainer
from dependency_injector.providers import Factory, Singleton

from infrastructure.repositories.moviemock import MovieMockRepository
from infrastructure.repositories.repertoiremock import RepertoireMockRepository
# from infrastructure.repositories.repertoiremock import RepertoireMockRepository

from infrastructure.services.movie import MovieService
from infrastructure.services.repertoire import RepertoireService
# from infrastructure.services.review import ReviewService

class Container(DeclarativeContainer):
    """Klasa kontenera dla celów wstrzykiwania zależnosci"""
    movie_repository = Singleton(MovieMockRepository)
    repertoire_repository = Singleton(RepertoireMockRepository)
    #review_repository = Singleton(ReviewMockRepository)

    movie_service = Factory(
        MovieService,
        repository=movie_repository,
    )
    repertoire_service = Factory(
        RepertoireService,
        repository=repertoire_repository,
    )
    """
    review_service = Factory(
        ReviewService,
        repository=review_repository,
    )
    """
