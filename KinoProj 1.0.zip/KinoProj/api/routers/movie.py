from container import Container
from dependency_injector.wiring import inject, Provide
from core.domain.movie import Movie, MovieIn
from infrastructure.services.imovie import IMovieService

from fastapi import APIRouter, Depends


router = APIRouter()

@router.get("/all", response_model=list(Movie), status_code=200)
async def get_all_movies(
    service: IMovieService = Depends(Provide[Container.movie_service])
) -> list:
    pass
    """punkt końcowy aby wydobyć wszystkie filmy"""

