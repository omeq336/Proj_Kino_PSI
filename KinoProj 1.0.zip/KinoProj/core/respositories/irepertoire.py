from abc import ABC, abstractmethod #mechanizm pozwalajacy tworzyc klasy abstrakcyjne Abstract Base Classes
from datetime import datetime
from typing import Iterable #

from core.domain.repertoire import Repertoire, RepertoireIn
from core.domain.movie import Movie, MovieIn

class IRepertoireRepository(ABC):
    """"""

    @abstractmethod
    async def get_all_movies_in_repertoire(self) -> Iterable[MovieIn]:
        pass

    @abstractmethod
    async def find_movies_by_title(self, title):
        pass

    @abstractmethod
    async def find_movies_by_genre(self, genre): # dubbing/ lektor
        pass

    @abstractmethod
    async def find_movies_by_age_restriction(self, age_restriction): # dubbing/ lektor
        pass

    @abstractmethod
    async def find_movies_by_rating(self, rating):  # dubbing/ lektor
        pass

    @abstractmethod
    async def find_movies_by_day(self, date):
        pass

    """tylko ADMIN"""
    @abstractmethod
    async def add_movie(self, movie:Movie):    #(self, id: int, movie: MovieIn, movie_time: datetime.time, movie_date: datetime, hall: str):
        pass

    async def remove_movie(self, movie_id: int):
        pass

    async def remove_repertoire(self, id):
        pass



