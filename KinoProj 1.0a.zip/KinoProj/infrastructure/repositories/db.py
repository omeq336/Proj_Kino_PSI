#Tymczasowa baza danych
repertoires: list = []
movies: list = []
reviews: list = []