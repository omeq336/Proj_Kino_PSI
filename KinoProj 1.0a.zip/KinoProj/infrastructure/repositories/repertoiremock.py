from core.domain.repertoire import Repertoire, RepertoireIn
from core.respositories.irepertoire import IRepertoireRepository
from infrastructure.repositories.db import repertoires
from core.domain.movie import MovieIn

from typing import Iterable


class RepertoireMockRepository(IRepertoireRepository):
    """"""

    async def get_all_movies_in_repertoire(self) -> Iterable[MovieIn]:
        pass

    async def find_movies_by_title(self, title):
        pass

    async def find_movies_by_genre(self, genre): # dubbing/ lektor
        pass

    async def find_movies_by_age_restriction(self, age_restriciton): # dubbing/ lektor
        pass

    async def find_movies_by_rating(self, rating):  # dubbing/ lektor
        pass

    async def find_movies_by_day(self, date):
        pass

    """tylko ADMIN"""
    async def add_movie(self, movie: MovieIn):    #(self, id: int, movie: MovieIn, movie_time: datetime.time, movie_date: datetime, hall: str):
        pass

    async def remove_movie(self, movie_id: int):
        pass

    async def remove_repertoire(self, id):
        pass



