from dependency_injector.wiring import inject, Provide
from fastapi import APIRouter, Depends

from container import Container
from core.domain.movie import Movie, MovieIn
from infrastructure.services.imovie import IMovieService



router = APIRouter()

@router.get("/all", response_model=list(Movie), status_code=200)
@inject
async def get_all_movies(
    service: IMovieService = Depends(Provide[Container.movie_service])
) -> list:
    pass
    """punkt końcowy aby wydobyć wszystkie filmy"""

@router.get("/movie/{id}", response_model=list(Movie, status_code=200))
@inject
async def get_movie_by_id(id: int, service: IMovieService = Depends(Provide[Container.movie_service])) -> list:
    pass

@router.get("/movie/{title}")
@inject
async def get_movie_by_title(title: str, service: IMovieService = Depends(Provide[Container.movie_service])) -> list:
    return await self._repository.get_movie_by_title(title)


async def get_movie_by_genre(self, genre: str):
    return await self._repository.get_movie_by_genre(genre)

async def get_movie_by_rating(self, rating: int):
    return await self._repository.get_movie_by_rating(rating)

async def get_movie_by_age_restriction(self, age: int):
    return await self._repository.get_movie_by_age_restriction(age)

